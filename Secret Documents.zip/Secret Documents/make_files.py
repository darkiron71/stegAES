import os

# Function to create txt files
def create_txt_files(num_files):
    current_dir = os.getcwd()
    for i in range(1, num_files + 1):
        file_name = f"file_{i}.txt"
        file_path = os.path.join(current_dir, file_name)
        with open(file_path, 'w') as f:
            f.write(f"This is file {i}")

# Create 10 txt files
create_txt_files(10)
